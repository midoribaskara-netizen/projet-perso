// Dark mode + changement image perso
function changemode() {
    const body = document.body;
    const btn = document.getElementById("mode-btn");
    const persoImg = document.getElementById("perso-img");
    const bannerImg = document.getElementById("banner-img");


    body.classList.toggle("dark-mode");
    btn.textContent = body.classList.contains("dark-mode") ? "Mode Family" : "Mode Espion";

    if(body.classList.contains("dark-mode")) {
        persoImg.src = "F.png"; // Image mode espion
        bannerImg.src = "sp.png";
    } else {
        persoImg.src = "anyaaaaa.png"; // Image normale
        bannerImg.src = "spy.png";
    }
}

// Menu burger
const hamMenu = document.querySelector('.ham-menu');
const burgerMenu = document.querySelector('.burger-menu');

hamMenu.addEventListener('click', () => {
    hamMenu.classList.toggle('active');
    burgerMenu.classList.toggle('active');
});

burgerMenu.addEventListener('click', () => {
    hamMenu.classList.remove('active');
    burgerMenu.classList.remove('active');
});
